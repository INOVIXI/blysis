/**
 * Answers `comparison.columns`: the products on one shelf, ready to be drawn
 * as the columns of a comparison.
 *
 * Everything visible comes from here at the moment the page is drawn - the
 * name, the price the availability window worked out, the picture, the way to
 * buy - so a table cannot go stale. Before this, a column was a label an
 * operator typed and a URL beside it, and the seeded table proved what that
 * costs: its columns read Free, VIP and Gold while the shop sold VIP, VIP+,
 * MVP, MVP+ and Legend.
 *
 * The same rules the shelf itself applies: a switched-off product is not a
 * column, and one whose window is shut is hidden exactly as it is on the grid.
 * A table is a way of drawing a category, not a way around it.
 */
import type { HookHandlerFor } from "@/core/sdk";
import { getTranslations } from "next-intl/server";
import { moduleSettings, prisma, siteTimeZone } from "@/core/sdk/server";
import { PUBLIC_PRODUCT } from "../lib/public-product";
import { effectivePrice } from "../lib/availability";
import { pricedForCampaign, runningCampaignEntries } from "../lib/campaign-server";
import { hideShut, onTheShelfWhere, rulesOf, type ProductRow } from "../lib/availability-server";
import { categoryIdIn } from "../lib/comparison-subject";
import { priceAfterCredit, upgradeCredit } from "../lib/upgrade-credit";
import { creditingPurchases } from "../lib/upgrade-credit-server";
import { auth } from "@/core/sdk/auth";

/** How many products one shelf may put in a table before it stops being one. */
const MOST_COLUMNS = 12;

const columns: HookHandlerFor<"comparison.columns", "filter"> = async (current, who) => {
    const categoryId = who?.subjectRef ? categoryIdIn(who.subjectRef) : null;
    if (!categoryId) return current;

    const now = new Date();
    const rows = await prisma.product.findMany({
        where: { ...onTheShelfWhere(now), categoryId },
        select: PUBLIC_PRODUCT,
        orderBy: [{ price: "asc" }, { createdAt: "asc" }],
        take: MOST_COLUMNS,
    });

    const zone = await siteTimeZone();
    const campaignEntries = await runningCampaignEntries(prisma, now, zone);
    const { lowStockAt } = await moduleSettings<{ lowStockAt: number }>("store");

    const visible = hideShut(rows as unknown as ProductRow[], now, zone);

    // A ladder is exactly where the upgrade credit matters most: the whole
    // point of the table is choosing the next rung up, and the price of that
    // rung is different for somebody already on one.
    /*
     * A session where there is a request to read one from, and nobody where
     * there is not.
     *
     * `auth()` reads the incoming headers and throws when no request is in
     * scope - synchronously, so a `.catch` on the promise never sees it. This
     * handler runs from the demo seed as well as from a page, and there it
     * threw: the bus caught it, so the filter answered with the value it was
     * handed, the seed read no columns as "this shelf has nothing to compare"
     * and wrote its table bound to nothing. The shelf then asked for a
     * subject no table carried and drew five ranks as an empty page.
     *
     * Nobody signed in is the right answer outside a request, and it is
     * already the answer for most callers inside one.
     */
    // Typed by what is read rather than by `ReturnType<typeof auth>`: `auth`
    // is overloaded and the last of its signatures returns a middleware, so
    // the inferred type is one this has never held.
    let session: { user?: { id?: string | null } } | null = null;
    try {
        session = await auth();
    } catch {
        session = null;
    }
    const ownedIds = await creditingPurchases(session?.user?.id);
    const ladder = visible.map((row) => ({
        id: row.id,
        categoryId,
        price: pricedForCampaign(row.id, effectivePrice(rulesOf(row), now), campaignEntries).price,
    }));
    /*
     * The reader's own language: this runs from an API route with no locale
     * in its path, so without being told it answers in the default and a
     * Turkish shopper was shown "19.99 off: you own a lower rank".
     *
     * Guarded for the same reason as the session above. `getTranslations`
     * wants a request as well, and without one it does not answer in the
     * default - it throws "not supported in Client Components", which is the
     * wrong sentence for the right problem. The two strings it makes are
     * notes to a shopper, and where there is no request there is no shopper:
     * a seed asking what a shelf's columns are wants the products, not the
     * line underneath them.
     */
    let t: Awaited<ReturnType<typeof getTranslations>> | null = null;
    try {
        t = who?.locale
            ? await getTranslations({ locale: who.locale, namespace: "store" })
            : await getTranslations("store");
    } catch {
        t = null;
    }

    // At most one column is emphasised. "Featured" is the operator's existing
    // mark for the one they want chosen, and a shop that has featured three
    // of five ranks has emphasised nothing - the cheapest of them is the one
    // a ladder points at.
    const emphasised = visible.find((row) => (row as unknown as { isFeatured: boolean }).isFeatured)?.id ?? null;

    return [
        ...current,
        ...visible.map((row) => {
            const source = row as unknown as {
                id: string; number: number; name: string; slug: string;
                stock: number | null; image: string | null; isFeatured: boolean;
                comparePrice: unknown;
            };
            const priced = pricedForCampaign(row.id, effectivePrice(rulesOf(row), now), campaignEntries);
            // The struck-through figure the card already shows. `effectivePrice`
            // only knows about a sale window; a plain compare-at price is the
            // other half of it, and a table without it prices a rank lower than
            // the card beside it does.
            const compareAt = source.comparePrice === null ? null : Number(source.comparePrice);
            const was = priced.was ?? (compareAt !== null && compareAt > priced.price ? compareAt : null);
            const credit = upgradeCredit({ id: source.id, categoryId, price: priced.price }, ladder, ownedIds);
            const path = `/store/product/${source.number}/${source.slug}`;
            const low = typeof lowStockAt === "number" && lowStockAt > 0
                && source.stock !== null && source.stock > 0 && source.stock <= lowStockAt;

            return {
                ref: source.id,
                label: source.name,
                image: source.image,
                price: priceAfterCredit(priced.price, credit),
                was,
                // What somebody with no history pays. The table draws the sale
                // badge from this rather than from the price, so a personal
                // credit is not advertised as a discount to everybody.
                fullPrice: priced.price,
                // One line under the price, and the upgrade outranks the stock:
                // "you already own VIP" changes what somebody pays, and "4
                // left" changes only how fast they decide. Written here rather
                // than in the table, because the shop is what knows the words
                // for its own offers.
                note: !t ? null : credit > 0
                    ? t("upgradeNote", { amount: credit.toFixed(2) })
                    : low ? t("leftInStock", { count: Number(source.stock) }) : null,
                href: path,
                buyHref: path,
                // Cheapest first, so the ladder reads upward.
                highlight: source.id === emphasised,
            };
        }),
    ];
};

export default columns;
