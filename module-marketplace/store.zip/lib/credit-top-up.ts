/**
 * A wallet top-up, settled from the row the store wrote when it started.
 *
 * The credits, the buyer and the price used to travel through the gateway as
 * metadata and come back the same way. Eight gateways have nowhere to carry
 * metadata, so their top-ups came back as an order nobody had placed and
 * credited nothing; on the gateways that do carry it, the store was trusting a
 * provider's echo for how much to put on an account. Every top-up is now a
 * `CreditTopUp` row, its id is the reference the gateway carries, and settling
 * one reads everything from the row.
 */
import { prisma, log } from "@/core/sdk/server";
import { applyFiltersAsync, doActionAsync } from "@/core/sdk";
import { chargeShortfall } from "./charge";
import { ALREADY, OK, failed, refused } from "./payment-outcome";

/** The columns of a `CreditTopUp` that settling one reads. */
export interface TopUpRow {
    id: string;
    userId: string | null;
    credits: number;
    amount: number | { toString(): string };
    /** The payment method's fee passed on, charged on top of `amount`. */
    fee?: number | { toString(): string } | null;
    currency: string;
    status: string;
    /** A bonus campaign's credits, decided when the payment started. */
    bonusCredits?: number | null;
}

/**
 * The ledger row id for one top-up.
 *
 * Deterministic on purpose: it is the idempotency key, enforced by the primary
 * key rather than by a search that two callers can both lose.
 */
function creditLedgerId(provider: string, providerRef: string): string {
    return `credit:${provider}:${providerRef}`;
}

export async function findTopUp(reference: string): Promise<TopUpRow | null> {
    return prisma.creditTopUp.findUnique({ where: { id: reference } });
}

/** Puts the credits a top-up sold on its buyer's account, once. */
export async function settleCredits(settlement: PaymentSettlement, topUp: TopUpRow): Promise<PaymentOutcome> {
    if (topUp.status === "COMPLETED") return ALREADY;
    if (!topUp.userId) return failed("the account that bought these credits no longer exists");
    const userId = topUp.userId;

    // Held against the price and the fee together, because both were asked
    // for: a payment that covers the credits and not the fee is short.
    const charged = Math.round((Number(topUp.amount) + Number(topUp.fee ?? 0)) * 100) / 100;
    const shortfall = chargeShortfall({ amount: charged, currency: topUp.currency }, settlement);
    if (shortfall) {
        log.error("[store] a top-up was paid for with less than it cost", {
            topUpId: topUp.id,
            provider: settlement.provider,
            providerRef: settlement.providerRef,
            shortfall,
        });
        return refused(`payment does not match the top-up: ${shortfall}`);
    }

    // The gateway's own id for the money is the ledger row's primary key, and
    // the top-up is claimed in the same transaction: either closes a retry
    // racing a reloaded return URL, and the claim also closes one top-up
    // reported under two gateway ids.
    //
    // Looking for the ledger row first and writing after closed nothing: a
    // retry and a reload arriving together both found no row, and both
    // credited the account.
    const ledgerId = creditLedgerId(settlement.provider, settlement.providerRef);

    try {
        const credited = await prisma.$transaction(async (tx) => {
            const claimed = await tx.creditTopUp.updateMany({
                where: { id: topUp.id, status: "PENDING" },
                data: { status: "COMPLETED", providerRef: settlement.providerRef },
            });
            if (claimed.count === 0) return false;
            // The wallet is another module's; the transaction is this one's,
            // and the deterministic id goes with the request so a duplicate
            // key still aborts it.
            await applyFiltersAsync("credit.change", { applied: false }, {
                tx,
                userId,
                amount: topUp.credits,
                type: "credit_purchase",
                description: `Purchased ${topUp.credits} credits via ${settlement.provider} (${settlement.providerRef})`,
                ledgerId,
            });
            // Its own row, so a member and an admin can tell the offer from
            // the purchase, and its own deterministic id, so a retry that
            // got past the claim still cannot pay it twice. Inside the same
            // transaction: a bonus written after it would be paid again by a
            // retry that lost the claim race.
            const bonus = Math.floor(Number(topUp.bonusCredits ?? 0));
            if (bonus > 0) {
                await applyFiltersAsync("credit.change", { applied: false }, {
                    tx,
                    userId,
                    amount: bonus,
                    type: "top_up_bonus",
                    description: `Top-up bonus for ${settlement.provider} (${settlement.providerRef})`,
                    ledgerId: `bonus:${ledgerId}`,
                });
            }
            return true;
        });
        if (!credited) return ALREADY;
    } catch (error) {
        // P2002 is the unique constraint: the other delivery won the race.
        if (error && typeof error === "object" && "code" in error && (error as { code: unknown }).code === "P2002") {
            return ALREADY;
        }
        throw error;
    }

    // Told once, after the money is on the account: a retry that lost the
    // race above returned already and says nothing.
    await doActionAsync("store.credits.purchased", { userId, amount: topUp.credits }).catch((error: unknown) => {
        log.warn("[store] a credit purchase could not be announced", {
            error: error instanceof Error ? error.message : String(error),
        });
    });
    return OK;
}

/** The buyer walked away from a top-up. Nothing was credited, so nothing is undone. */
export async function cancelTopUp(topUp: TopUpRow): Promise<PaymentOutcome> {
    const cancelled = await prisma.creditTopUp.updateMany({
        where: { id: topUp.id, status: "PENDING" },
        data: { status: "CANCELLED" },
    });
    return cancelled.count === 0 ? ALREADY : OK;
}

/**
 * The money for a top-up went back: take its credits back off the account.
 *
 * A campaign bonus goes back with them, in the same debit: it was given for
 * money that is no longer here.
 *
 * As far as the balance still holds them. A debit the balance cannot cover is
 * refused by the wallet, and the credits already spent are what an operator
 * has to chase; the error log says how many. Stamped in the same transaction,
 * so a second refund notice takes nothing twice.
 */
export async function refundTopUp(provider: string, providerRef: string): Promise<PaymentOutcome> {
    const topUp = await prisma.creditTopUp.findFirst({
        where: { provider, providerRef },
        select: { id: true, userId: true, credits: true, bonusCredits: true, refundedAt: true },
    });
    if (!topUp) return failed("unknown payment");
    if (topUp.refundedAt) return ALREADY;
    const given = topUp.credits + Math.max(0, Math.floor(Number(topUp.bonusCredits ?? 0)));

    const kept = await prisma.$transaction(async (tx) => {
        const claimed = await tx.creditTopUp.updateMany({
            where: { id: topUp.id, refundedAt: null },
            data: { refundedAt: new Date() },
        });
        if (claimed.count === 0) return null;
        if (!topUp.userId) return 0;
        const holder = await tx.user.findUnique({ where: { id: topUp.userId }, select: { creditBalance: true } });
        const take = Math.min(given, Math.max(0, Math.floor(Number(holder?.creditBalance ?? 0))));
        if (take > 0) {
            await applyFiltersAsync("credit.change", { applied: false }, {
                tx,
                userId: topUp.userId,
                amount: -take,
                type: "payment_refund",
                description: `Refunded via ${provider} (${providerRef})`,
                ledgerId: `refund:${creditLedgerId(provider, providerRef)}`,
            });
        }
        return given - take;
    });
    if (kept === null) return ALREADY;
    if (kept > 0) {
        log.error("[store] a refunded top-up's credits were already spent", { topUpId: topUp.id, provider, providerRef, kept });
    }
    return OK;
}
