// Pure checkout pricing math, extracted verbatim from api/checkout/route.ts so
// the money calculations can be unit-tested without a DB, Stripe, or auth.
//
// These functions take plain numbers/objects (the route still does the
// Prisma Decimal -> Number() coercion at the call site) and contain NO I/O.
// Behaviour is identical to the previous inline implementation; the route
// imports computeOrderPricing/computeCouponDiscount/computeTotals instead of
// inlining the arithmetic.

/**
 * Money, to the cent.
 *
 * Every number here is a currency amount, and a currency amount that is not a
 * whole number of cents cannot be charged. A percentage discount produces one
 * immediately (33% off 9.99 is 6.6933), and nothing downstream used to round
 * it: the order was stored at 6.6933, the receipt showed 6.69, and each
 * gateway rounded on its own terms - Stripe per line, iyzico with toFixed(2),
 * PayTR on the total. So the amount charged, the amount recorded and the
 * amount shown could all differ, and the gap grew with the quantity.
 *
 * Rounding once, here, at the moment each amount is computed, makes those
 * three agree by construction: everything downstream already receives whole
 * cents, so a gateway's own rounding becomes a no-op.
 */
const cents = (amount: number): number => Math.round(amount * 100) / 100;

export interface PricingProduct {
    id: string;
    name: string;
    type?: string | null;
    price: number;
    categoryId?: string | null;
}

export interface PricingItemInput {
    productId: string;
    quantity: number;
}

export interface PricingBulkDiscount {
    minQuantity: number;
    discountPercent: number;
    productId?: string | null;
    categoryId?: string | null;
}

export interface ComputedOrderItem {
    productId: string;
    name: string;
    price: number;
    quantity: number;
    metadata: {
        type: string | null | undefined;
        variables: Record<string, string>;
        bulkDiscount?: number;
    };
}

/**
 * Per-item price resolution: cumulative-upgrade credit (pay only the
 * difference when the buyer already owns a cheaper product in the same
 * category) followed by the best matching bulk discount. Returns the line
 * items plus the running subtotal.
 *
 * `bulkDiscounts` must already be ordered most-aggressive-first (the route
 * fetches them `orderBy: { discountPercent: "desc" }`) because we take the
 * first match.
 */
export function computeOrderPricing(params: {
    items: PricingItemInput[];
    products: PricingProduct[];
    bulkDiscounts: PricingBulkDiscount[];
    ownedProductIds: Set<string>;
    variables?: Record<string, Record<string, string>>;
}): { subtotal: number; orderItems: ComputedOrderItem[] } {
    const { items, products, bulkDiscounts, ownedProductIds, variables } = params;

    let subtotal = 0;
    const orderItems = items.map((item): ComputedOrderItem => {
        const product = products.find((p) => p.id === item.productId)!;
        let price = Number(product.price);

        // Cumulative upgrade: pay difference if user owns cheaper in same category
        if (product.categoryId) {
            const ownedInCategory = products.filter(
                (p) => p.categoryId === product.categoryId && ownedProductIds.has(p.id) && Number(p.price) < price
            );
            if (ownedInCategory.length > 0) {
                const highestOwned = Math.max(...ownedInCategory.map((p) => Number(p.price)));
                price = Math.max(0, price - highestOwned);
            }
        }

        // Bulk discount: find best matching discount for this item
        const matchingBulk = bulkDiscounts.find((bd) =>
            bd.minQuantity <= item.quantity &&
            (bd.productId === product.id || bd.categoryId === product.categoryId || (!bd.productId && !bd.categoryId))
        );
        let bulkDiscountApplied = 0;
        if (matchingBulk) {
            bulkDiscountApplied = matchingBulk.discountPercent;
            price = price * (1 - matchingBulk.discountPercent / 100);
        }

        // Rounded before the quantity multiplies it: a third of a cent on
        // one seat is a cent on the fourth, and the gateway bills per line.
        price = cents(price);
        subtotal += price * item.quantity;

        return {
            productId: product.id,
            name: product.name,
            price,
            quantity: item.quantity,
            metadata: {
                type: product.type,
                variables: variables?.[product.id] || {},
                ...(bulkDiscountApplied > 0 ? { bulkDiscount: bulkDiscountApplied } : {}),
            },
        };
    });

    return { subtotal: cents(subtotal), orderItems };
}

// Prisma money columns arrive as Decimal objects, not primitives. Every
// numeric read in computeCouponDiscount already goes through Number(), which
// coerces a Decimal via its valueOf/toString - so we accept either here to
// keep the route's behaviour identical while satisfying the type checker.
type DecimalLike = number | { toString(): string };

export interface CouponInput {
    isActive: boolean;
    type: string; // "PERCENTAGE" | other (fixed)
    value: DecimalLike;
    maxDiscount?: DecimalLike | null;
    minPurchase?: DecimalLike | null;
    usageLimit?: number | null;
    usageCount?: number;
    startsAt?: Date | null;
    expiresAt?: Date | null;
}

export interface CouponResult {
    /** Human-readable rejection reason, or null when the coupon applies. */
    error: string | null;
    /** Discount amount in currency units (0 when rejected). */
    discount: number;
}

/**
 * Validate + price a coupon against the current subtotal. Mirrors the inline
 * transaction body in the route: not-found/inactive, not-yet-active, expired,
 * usage-cap, and min-purchase gates all reject with a message; PERCENTAGE
 * applies value% (capped at maxDiscount), otherwise a fixed amount capped at
 * the subtotal. `now` is injectable for deterministic tests.
 */
export function computeCouponDiscount(
    coupon: CouponInput | null | undefined,
    subtotal: number,
    now: Date = new Date()
): CouponResult {
    if (!coupon || !coupon.isActive) return { error: "Coupon code not found or inactive", discount: 0 };

    if (coupon.startsAt && coupon.startsAt > now) return { error: "Coupon is not yet active", discount: 0 };
    if (coupon.expiresAt && coupon.expiresAt < now) return { error: "Coupon has expired", discount: 0 };
    if (coupon.usageLimit && (coupon.usageCount ?? 0) >= coupon.usageLimit) {
        return { error: "Coupon usage limit reached", discount: 0 };
    }
    if (coupon.minPurchase && subtotal < Number(coupon.minPurchase)) {
        return { error: `Coupon requires a minimum purchase of ${Number(coupon.minPurchase)}`, discount: 0 };
    }

    let discount: number;
    if (coupon.type === "PERCENTAGE") {
        discount = subtotal * (Number(coupon.value) / 100);
        if (coupon.maxDiscount) discount = Math.min(discount, Number(coupon.maxDiscount));
    } else {
        discount = Math.min(Number(coupon.value), subtotal);
    }
    return { error: null, discount: cents(discount) };
}

/**
 * Creator-code discount: a percentage of the subtotal AFTER the coupon has
 * been applied. Returns 0 for a missing/zero percent.
 */
export function computeCreatorDiscount(
    subtotal: number,
    couponDiscount: number,
    discountPercent: number
): number {
    const afterCoupon = subtotal - couponDiscount;
    return cents(afterCoupon * (discountPercent / 100));
}

/**
 * A creator's cut of an order.
 *
 * Paid into a credit balance and written to the ledger, so it is money in the
 * same sense the order total is: a commission of 7.5% on 17.51 is 1.313825,
 * and a balance cannot hold that.
 */
export function computeCreatorCommission(total: number, commissionPercent: number): number {
    return cents(total * (commissionPercent / 100));
}

/**
 * Final tax + total roll-up, clamped so a discount that exceeds the subtotal
 * can never produce a negative charge. `taxRate` is a percentage (e.g. 8 for
 * 8%); the rounding (round to cents) matches the route's Math.round(.. )/100.
 */
export function computeTotals(params: {
    subtotal: number;
    couponDiscount: number;
    creatorDiscount: number;
    taxRate: number;
    /**
     * Whether the prices already contain the tax.
     *
     * Adding tax on top is how a shop quotes a price in one part of the world
     * and wrong in most of the rest: where a consumer price is quoted
     * tax-inclusive by law, adding it at checkout charges more than the page
     * said and puts the wrong figure on the invoice.
     */
    taxIncluded?: boolean;
}): { totalDiscount: number; taxableAmount: number; tax: number; total: number } {
    const { subtotal, couponDiscount, creatorDiscount, taxRate, taxIncluded = false } = params;
    const totalDiscount = cents(couponDiscount + creatorDiscount);
    const discounted = cents(Math.max(0, subtotal - totalDiscount));

    if (taxRate <= 0) {
        return { totalDiscount, taxableAmount: discounted, tax: 0, total: discounted };
    }

    if (taxIncluded) {
        // The tax inside a gross figure is not a percentage of it. At 20 per
        // cent the tax inside 120 is 20, not 24, and the difference is what an
        // invoice is checked against.
        //
        // The net is derived and the tax is the remainder, rather than both
        // being rounded from the gross: rounding twice is how a line item
        // comes out a penny short of what the customer was charged.
        const net = cents(discounted / (1 + taxRate / 100));
        return { totalDiscount, taxableAmount: net, tax: cents(discounted - net), total: discounted };
    }

    const tax = cents((discounted * taxRate) / 100);
    return { totalDiscount, taxableAmount: discounted, tax, total: cents(discounted + tax) };
}

/** A processor's cut, as an operator enters it. */
export interface ProcessorFee {
    /** Percentage of the charge. */
    percent: number;
    /** Flat amount per transaction, in the order's currency. */
    fixed: number;
}

/**
 * What to charge so the shop is left with what it asked for.
 *
 * The obvious way to pass a fee on is to add the percentage to the total, and
 * it is wrong: the processor takes its cut of the larger amount too. A shop
 * adding 2.9 per cent to a 100 charge is paid 102.90 and keeps 99.92 - short
 * by almost exactly the fee it was trying not to pay.
 *
 * So it divides rather than multiplies, and the fixed part goes inside the
 * division because the processor takes its percentage of the whole charge,
 * including the part covering its own flat fee.
 *
 * A percentage that would eat the entire payment is a number somebody typed,
 * not a fee. 100 divides by zero and anything above it goes negative, so the
 * charge is left alone rather than turned into infinity.
 */
export function grossUpForFee(net: number, fee: ProcessorFee): { charged: number; surcharge: number } {
    const percent = Number.isFinite(fee.percent) ? fee.percent : 0;
    const fixed = Number.isFinite(fee.fixed) ? fee.fixed : 0;
    if (net <= 0 || percent < 0 || percent >= 100 || (percent === 0 && fixed <= 0)) {
        return { charged: cents(Math.max(0, net)), surcharge: 0 };
    }
    const charged = cents((net + Math.max(0, fixed)) / (1 - percent / 100));
    return { charged, surcharge: cents(charged - net) };
}
