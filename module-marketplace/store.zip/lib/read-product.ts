/**
 * One product as a visitor may see it.
 *
 * The page that shows a product is a client component and fetched it on mount,
 * so not a word of a product - not its name, not its description, not its
 * price - was ever in the HTML the server sent. All 34 product URLs the
 * sitemap publishes were empty pages to a reader without JavaScript and to
 * anything that indexes one.
 *
 * The page renders this on the server now and the endpoint still calls it, so
 * the rules about what a visitor may see are written once. Two of them matter:
 * a switched-off product never leaves the database, and a product an operator
 * asked to hide while it is shut answers exactly as one that does not exist,
 * so the two cannot be told apart.
 */
import { isAdmin, moduleSettings, prisma, siteTimeZone } from "@/core/sdk/server";
import { auth } from "@/core/sdk/auth";
import { PUBLIC_PRODUCT } from "./public-product";
import { availabilityFor, rulesOf, type ProductRow } from "./availability-server";
import { offerPrice, runningCampaignEntries } from "./campaign-server";
import { withStoreSale } from "./store-sale";
import { runningStoreSales } from "./store-sale-server";
import { priceAfterCredit, upgradeCredit } from "./upgrade-credit";
import { creditingPurchases, ownedRungsOn } from "./upgrade-credit-server";
import { productsIn } from "./store-text";
import { publicVariants } from "./variants";

export type ProductRead = Awaited<ReturnType<typeof readProduct>>;

/** `locale` names it and its shelf in the shopper's language; none reads the originals. */
export async function readProduct(id: string, locale = "") {
    const found = await prisma.product.findFirst({
        where: {
            isActive: true,
            OR: [{ id }, { slug: id }, ...(isNaN(Number(id)) ? [] : [{ number: Number(id) }])],
        },
        // The variants hold their commands, so they are read here and
        // never by the shared public select: `publicVariants` decides what
        // of them a page sees.
        select: { ...PUBLIC_PRODUCT, variants: true },
    });
    if (!found) return null;
    const [product] = await productsIn([found], locale);

    // Per-person counting needs the session, which is also why an answer built
    // here is never shared-cached the way the listing is.
    const session = await auth();
    const state = await availabilityFor(prisma, product as unknown as ProductRow, session?.user?.id ?? null);

    const hidden = product.outsideWindow === "hidden" && state.state !== "open" && state.state !== "limit_reached";
    if (hidden && !(session?.user?.id && (await isAdmin(session.user.id)))) return null;

    const { lowStockAt } = await moduleSettings<{ lowStockAt: number }>("store");

    // The price the card on the shelf shows and the till takes: a running
    // campaign, then a store-wide sale where one covers this shelf and beats
    // it (see `withStoreSale`). The availability answer carries the sale
    // window alone.
    const now = new Date();
    const campaignEntries = await runningCampaignEntries(prisma, now, await siteTimeZone());
    const priced = withStoreSale(
        offerPrice({ ...rulesOf(product as unknown as ProductRow), id: product.id }, campaignEntries, now),
        { listPrice: Number(product.price), categoryId: product.category?.id },
        await runningStoreSales(now),
        now,
    );

    // What this reader pays rather than what the product costs. Somebody
    // standing on a lower rung of the same ladder pays the difference, and
    // until now the only place that was true was the checkout.
    const ownedIds = await creditingPurchases(session?.user?.id);
    const ladder = await ownedRungsOn([product.category?.id], ownedIds);
    const credit = upgradeCredit(
        { id: product.id, categoryId: product.category?.id ?? null, price: priced.price },
        ladder,
        ownedIds,
    );

    const { variants: rawVariants, ...shown } = product;
    return {
        ...shown,
        /** What it is sold as, for this reader; empty sells the product itself. */
        variants: publicVariants(rawVariants, locale || "en", {
            listPrice: Number(product.price),
            offeredPrice: priced.price,
            credit,
            durationDays: product.durationDays ?? null,
        }),
        /*
         * A number, not a Decimal.
         *
         * `price` is replaced below with the one the window worked out, which
         * is already a number; `comparePrice` and `salePrice` came straight
         * off the row. Over HTTP they arrived as strings, which every screen
         * that reads them declared as `number` and multiplied - so the type
         * was a fiction the JSON boundary hid. Converted once, here.
         */
        comparePrice: product.comparePrice === null ? null : Number(product.comparePrice),
        salePrice: product.salePrice === null ? null : Number(product.salePrice),
        lowStockAt,
        availability: {
            state: state.state,
            buyable: state.buyable,
            opensAt: state.opensAt,
            closesAt: state.closesAt,
            remainingForPerson: state.remainingForPerson,
            remainingInPeriod: state.remainingInPeriod,
        },
        price: priceAfterCredit(priced.price, credit),
        was: priced.was,
        onSale: priced.onSale,
        /** Taken off because a cheaper rung on this ladder is already owned. */
        upgradeCredit: credit,
        /** What it costs somebody who owns nothing on this shelf. */
        fullPrice: priced.price,
    };
}
