/**
 * The shop's front, read on the server.
 *
 * The store index fetched its categories and its products after the page had
 * loaded and kept the chosen category in client state. Two things followed.
 * The HTML the server sent held no link to a single product - measured, the
 * page answered with 17 links and every one of them was the shared header and
 * footer, so the 34 product URLs in the sitemap had no path into them from
 * anywhere on the site. And no category had an address at all: a section of
 * the shop could not be linked to, shared, or opened twice in a row.
 *
 * The rules about what is on the shelf are the ones the listing endpoint
 * applies, and they live here now so the two cannot disagree: switched off is
 * a filter rather than a check after the fact, and the hour of a weekly window
 * is applied in `hideShut` rather than in SQL.
 */
import { moduleSettings, prisma, siteTimeZone, textContains } from "@/core/sdk/server";
import { auth } from "@/core/sdk/auth";
import { priceAfterCredit, upgradeCredit } from "./upgrade-credit";
import { creditingPurchases } from "./upgrade-credit-server";
import { PUBLIC_PRODUCT } from "./public-product";
import { availabilityOf } from "./availability";
import { offerPrice, runningCampaignEntries } from "./campaign-server";
import { withStoreSale } from "./store-sale";
import { runningStoreSales } from "./store-sale-server";
import { hideShut, onTheShelfWhere, rulesOf, type ProductRow } from "./availability-server";
import { categoriesIn, productsIn, productsTranslatedAs } from "./store-text";
import { publicVariants, type PublicVariant } from "./variants";

export const PRODUCTS_PER_PAGE = 12;

function lowestOf(variants: PublicVariant[]): number | null {
    return variants.length > 0 ? Math.min(...variants.map((variant) => variant.price)) : null;
}

export type StoreSort = "newest" | "price_asc" | "price_desc" | "popular";

export const STORE_SORTS: StoreSort[] = ["newest", "price_asc", "price_desc", "popular"];

export interface StoreCategory {
    id: string;
    name: string;
    slug: string;
    image: string | null;
    description: string | null;
    /** `grid` or `table`: how this shelf is drawn. */
    layout: string;
    parentId: string | null;
    children: { id: string; name: string; slug: string; image: string | null; description: string | null }[];
}

/**
 * Every section a shopper may see, roots first with their children attached,
 * named in `locale` and in the operator's original where it has none.
 */
export async function readStoreCategories(locale = ""): Promise<StoreCategory[]> {
    const rows = await prisma.category.findMany({
        where: { isActive: true },
        orderBy: { order: "asc" },
        take: 300,
        select: {
            id: true, name: true, slug: true, image: true, description: true, layout: true, parentId: true,
            children: {
                where: { isActive: true },
                orderBy: { order: "asc" },
                select: { id: true, name: true, slug: true, image: true, description: true },
            },
        },
    });
    return categoriesIn(rows, locale);
}

/**
 * One product as a shelf draws it.
 *
 * Named, and built field by field rather than spread from the row, because
 * this crosses into a Client Component. `price` was already a number - the
 * window works it out - but `comparePrice` and `salePrice` came straight off
 * Prisma as `Decimal`, and React refuses to serialise one: every visit to a
 * category threw "Only plain objects can be passed to Client Components".
 *
 * It went unnoticed because the page handed the row over as `as never`, which
 * is a cast that agrees with anything. `readProduct` had already converted the
 * same two columns for the same reason; the listing had not.
 */
export interface ShelfProduct {
    id: string;
    number: number;
    name: string;
    slug: string;
    /** What this reader pays: the credit for what they own is already off it. */
    price: number;
    /** Taken off because they already own a cheaper rung. Zero for most people. */
    upgradeCredit: number;
    /** What it costs somebody who owns nothing on this shelf. */
    fullPrice: number;
    comparePrice: number | null;
    was: number | null;
    onSale: boolean;
    image: string | null;
    /** The one line about it a card has room for. */
    shortDesc: string | null;
    /** How long a purchase lasts, in days; null is owned outright. */
    durationDays: number | null;
    /**
     * The lowest price a variant sells for, for "from" on the card, any offer
     * and credit taken off; null for a product sold as itself.
     */
    fromPrice: number | null;
    stock: number | null;
    isFeatured: boolean;
    category: { id: string; name: string; slug: string } | null;
    availability: {
        state: string;
        buyable: boolean;
        opensAt: string | null;
        closesAt: string | null;
        restricted: boolean;
    };
}

export interface StoreProducts {
    products: ShelfProduct[];
    lowStockAt: number;
    page: number;
    pages: number;
    total: number;
}

/**
 * One page of products, annotated the way the card expects.
 *
 * Almost nobody in particular: no per-person limit counting and no rank gate,
 * because those hide things and the shelf is the same list for everybody.
 *
 * The price is not the same for everybody. A shop selling a ladder makes a
 * different offer to somebody standing on it - pay the difference - and that
 * offer was invisible until the checkout took the money: the card said 19.99
 * and the charge was 10.00. A price nobody can see before they commit is not
 * an offer.
 */
export async function readStoreProducts(options: {
    categorySlug?: string;
    search?: string;
    sort: StoreSort;
    page: number;
    /** Only the products marked featured. */
    featured?: boolean;
    /** Leave this one out: the product a page is about. */
    exceptId?: string;
    /** Fewer than a page, for a front that shows a taste of a shelf. */
    perPage?: number;
    /** The shopper's language, for the products' and shelves' names. */
    locale?: string;
}): Promise<StoreProducts> {
    const now = new Date();
    const page = Math.max(1, Math.floor(options.page) || 1);
    const perPage = options.perPage ?? PRODUCTS_PER_PAGE;
    // A product found by its name in another language too: the shopper may
    // know it by the English name of a product written in Turkish.
    const translated = options.search ? await productsTranslatedAs(options.search) : [];
    const where = {
        ...onTheShelfWhere(now),
        ...(options.categorySlug ? { category: { slug: options.categorySlug } } : {}),
        ...(options.featured ? { isFeatured: true } : {}),
        ...(options.exceptId ? { id: { not: options.exceptId } } : {}),
        // Inside an AND: the shelf's own window is the top-level OR, and a
        // search spread beside it replaced it.
        ...(options.search
            ? { AND: [{ OR: [...textContains(["name", "description"], options.search), ...(translated.length > 0 ? [{ id: { in: translated } }] : [])] }] }
            : {}),
    };

    const [products, total] = await Promise.all([
        prisma.product.findMany({
            where,
            // With the variants, which only `publicVariants` passes on.
            select: { ...PUBLIC_PRODUCT, variants: true },
            skip: (page - 1) * perPage,
            take: perPage,
            orderBy: options.sort === "popular" ? [{ unitsSold: "desc" as const }, { createdAt: "desc" as const }]
                : options.sort === "price_asc" ? { price: "asc" as const }
                : options.sort === "price_desc" ? { price: "desc" as const }
                : { createdAt: "desc" as const },
        }),
        prisma.product.count({ where }),
    ]);

    const zone = await siteTimeZone();
    // Once for the whole page: a shop runs few campaigns, and asking each
    // product for its entry would be a query a line.
    const campaignEntries = await runningCampaignEntries(prisma, now, zone);
    const storeSales = await runningStoreSales(now);
    const { lowStockAt } = await moduleSettings<{ lowStockAt: number }>("store");
    const pricedNow = (row: ProductRow) => withStoreSale(
        offerPrice({ ...rulesOf(row), id: row.id }, campaignEntries, now),
        { listPrice: rulesOf(row).price, categoryId: (row as unknown as { category: { id: string } | null }).category?.id },
        storeSales,
        now,
    );

    // Once for the page: empty for a visitor, and for a shop that has turned
    // the credit off.
    const session = await auth();
    const ownedIds = await creditingPurchases(session?.user?.id);

    // In the shopper's language before anything is worked out from the rows,
    // so every line below reads the words the card will draw.
    const named = await productsIn(products, options.locale ?? "");
    const visible = hideShut(named as unknown as ProductRow[], now, zone);
    // The rungs of every ladder on this page, priced the way the cards are.
    // A credit is worked out against what is on the shelf, so it is the same
    // list the reader is looking at.
    const ladder = visible.map((other) => ({
        id: other.id,
        categoryId: (other as unknown as { category: { id: string } | null }).category?.id ?? null,
        price: pricedNow(other).price,
    }));

    const annotated: ShelfProduct[] = visible.map((row) => {
        const rules = rulesOf(row);
        const state = availabilityOf({ ...rules, roleIds: [] }, { boughtByPerson: 0, soldInPeriod: 0 }, now, zone);
        const priced = pricedNow(row);
        const credit = upgradeCredit(
            {
                id: row.id,
                categoryId: (row as unknown as { category: { id: string } | null }).category?.id ?? null,
                price: priced.price,
            },
            ladder,
            ownedIds,
        );
        const source = row as unknown as {
            id: string; number: number; name: string; slug: string;
            comparePrice: unknown; image: string | null; shortDesc: string | null; durationDays: number | null;
            stock: number | null; isFeatured: boolean;
            category: { id: string; name: string; slug: string } | null;
        };
        return {
            id: source.id,
            number: source.number,
            name: source.name,
            slug: source.slug,
            price: priceAfterCredit(priced.price, credit),
            upgradeCredit: credit,
            fullPrice: priced.price,
            comparePrice: source.comparePrice === null ? null : Number(source.comparePrice),
            was: priced.was,
            onSale: priced.onSale,
            image: source.image,
            shortDesc: source.shortDesc ?? null,
            durationDays: source.durationDays ?? null,
            fromPrice: lowestOf(publicVariants((row as unknown as { variants: unknown }).variants, options.locale || "en", {
                listPrice: rules.price,
                offeredPrice: priced.price,
                credit,
                durationDays: source.durationDays ?? null,
            })),
            stock: source.stock,
            isFeatured: source.isFeatured,
            category: source.category,
            availability: {
                state: state.state,
                buyable: state.buyable,
                opensAt: state.opensAt ? state.opensAt.toISOString() : null,
                closesAt: state.closesAt ? state.closesAt.toISOString() : null,
                restricted: row.roleIds.length > 0,
            },
        };
    });

    return {
        products: annotated,
        lowStockAt,
        page,
        pages: Math.max(1, Math.ceil(total / perPage)),
        total,
    };
}

/**
 * The product the shop is pushing: the newest one marked featured that is on
 * the shelf, priced the way its card is. Null when nothing is featured.
 */
export async function readFeatured(locale = ""): Promise<ShelfProduct | null> {
    const { products } = await readStoreProducts({ featured: true, sort: "newest", page: 1, perPage: 1, locale });
    return products[0] ?? null;
}

export interface FrontShelf {
    category: StoreCategory;
    products: ShelfProduct[];
    /** Everything on the shelf, for the link to the rest of it. */
    total: number;
}

/**
 * A taste of every top-level section: its first products, newest first, and
 * how many it holds. A section with nothing on its own shelf, one whose
 * products all sit in its children for one, is left out.
 */
export async function readShelves(categories: StoreCategory[], limit: number, locale = ""): Promise<FrontShelf[]> {
    const roots = categories.filter((c) => c.parentId === null);
    const shelves = await Promise.all(roots.map(async (category) => {
        const { products, total } = await readStoreProducts({ categorySlug: category.slug, sort: "newest", page: 1, perPage: limit, locale });
        return { category, products, total };
    }));
    return shelves.filter((s) => s.products.length > 0);
}

/** The other products on a product's shelf, newest first; none for one with no shelf. */
export async function readRelated(product: { id: string; categorySlug: string | null }, limit: number, locale = ""): Promise<ShelfProduct[]> {
    if (!product.categorySlug) return [];
    const { products } = await readStoreProducts({ categorySlug: product.categorySlug, exceptId: product.id, sort: "newest", page: 1, perPage: limit, locale });
    return products;
}
